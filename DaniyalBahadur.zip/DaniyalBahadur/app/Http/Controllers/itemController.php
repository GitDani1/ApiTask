<?php

namespace App\Http\Controllers;
use App\Models\inventoryTable;
use Illuminate\Http\Request;

class itemController extends Controller
{
    
    //create
  function insertData(Request $request)
  {
        $data= new inventoryTable();
        $data->name = $request->input('gulab jamun');
        $data->quantity = $request->input('1');
        $data->price = $request->input('100');
        $data->category = $request->input('sweet');
        $data->save();
        return response()->json($data);
  }
 /* function updateData(Request $req)
    {
        $data=inventoryTable::find($req->id);
        $data->name=$req->name;
        $data->price=$req->price;
        $data->quantity=$req->quantity;
        $data->category=$req->category;
        $data->save();
        if ($data) {
            echo json_encode(['msg' => 'Data Updated Successfully!']);
        } else {
            echo json_encode(['msg' => 'Error in Updating data']);
        }

    }
    */
  /*function showData($id)
  {
    $data=inventoryTable::find($id);
    if ($data > 0) {
        echo json_encode($data);
    } else {
        echo json_encode(['msg' => 'Data Not Found']);
    }
  } */

  function showData()
    {
        $data= inventoryTable::all();
        return response()->json($data);
    }

  function showDataById($id){
    $data= inventoryTable::find($id);
        return response()->json($data);
  }

  function updateDataById(Request $request,$id){
    $data= inventoryTable::find($id);
    $data->name = $request->input('gulab jamun');
    $data->quantity = $request->input('1');
    $data->price = $request->input('100');
    $data->category = $request->input('sweet');
    $data->save();
    return response()->json($data);
  }

  function deleteDataById(Request $request,$id){
    $data= inventoryTable::find($id);
        $data->delete();
        return response()->json($data);
  }
  
  function deleteData($id)
  {
        $data=inventoryTable::find($id);
        $data->delete();
        if ($data) {
            echo json_encode(['msg' => 'Data Deleted Successfully']);
        } else {
            echo json_encode(['msg' => 'Data Not Deleted']);
        }
}    
}
